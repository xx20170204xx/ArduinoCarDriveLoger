using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MeterBase : MonoBehaviour
{
    private Quaternion init_rot;
    // Start is called before the first frame update
    public Image needle = null;
    public Text text = null;

    /*
     * https://docs.microsoft.com/ja-jp/dotnet/standard/base-types/standard-numeric-format-strings
     */
    public string format = "{0:F0}";

    public float value = 0.0f;
    public float valueMin = 0.0f;
    public float valueMax = 360.0f;

    [Range(0,720)]
    public float angle_max = 360.0f;
    void Start()
    {
        if (needle == null && 
            text == null)
        {
            Debug.LogError("needle is not set.");
            this.gameObject.SetActive(false);
        }
        init_rot = needle.transform.rotation;
    } /* Start */

    // Update is called once per frame
    void Update()
    {
        value = Mathf.Clamp(value, valueMin, valueMax);

        UpdateNeedle();
        UpdateText();
    } /* Update */

    private void UpdateNeedle()
    {
        if (needle == null)
        {
            return;
        }
        float angle;
        float _per = valueMax - valueMin;

        angle = angle_max * ((value - valueMin) / _per);
        angle = -angle;


        needle.transform.rotation = init_rot * Quaternion.AngleAxis(angle, Vector3.forward);

    } /* UpdateNeedle */

    private void UpdateText()
    {
        if (text == null)
        {
            return;
        }
        text.text = string.Format(format, value);
    } /* UpdateText */
}

